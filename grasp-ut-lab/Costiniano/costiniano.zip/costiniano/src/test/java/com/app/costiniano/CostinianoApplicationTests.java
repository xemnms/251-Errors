package com.app.costiniano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostinianoApplicationTests {

	@Test
	void contextLoads() {
	}

}
