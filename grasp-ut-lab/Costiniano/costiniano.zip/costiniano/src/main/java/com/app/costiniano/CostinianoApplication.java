package com.app.costiniano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CostinianoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CostinianoApplication.class, args);
	}

}
